filename = 'dataBaseFile.dat'
address = "127.0.0.1"
port = 8080
url = "http://"+address+":"+ str(port)+"/"